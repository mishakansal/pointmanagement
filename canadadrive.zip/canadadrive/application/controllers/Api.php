<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('api_model');
		$this->load->library('form_validation');
	}

	function index()
	{
		$data = $this->api_model->fetch_all();
		echo json_encode($data->result_array());
	}

	function insert()
	{
		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('point', 'Point', 'required');
		if($this->form_validation->run())
		{
			$data = array(
				'name'	=>	$this->input->post('name'),
				'point'		=>	$this->input->post('point'),
				'age'		=>	$this->input->post('age'),
				'address'		=>	$this->input->post('address')
			);

			$this->api_model->insert_api($data);

			$array = array(
				'success'		=>	true
			);
		}
		else
		{
			$array = array(
				'error'					=>	true,
				'name_error'		=>	form_error('name'),
				'point_error'		=>	form_error('point')
			);
		}
		echo json_encode($array);
	}

	function updatepoints()
	{
		$this->form_validation->set_rules('point', 'Point', 'required');
		if($this->form_validation->run())
		{
			if($this->input->post('point') >= 0){
			$data = array(
				'point'			=>	$this->input->post('point')
			);

			$this->api_model->update_api($this->input->post('id'), $data);

			$array = array(
				'success'		=>	true
			);
		}else{
			$array = array(
				'error'				=>	true,
				'point_error'	=>	"Points cant be less than 0."
			);

		}
		}
		else
		{
			$array = array(
				'error'				=>	true,
				'point_error'	=>	form_error('point')
			);
		}
		echo json_encode($array);
	}
	
	function fetch_single()
	{
		if($this->input->post('id'))
		{
			$data = $this->api_model->fetch_single_user($this->input->post('id'));

			foreach($data as $row)
			{
				$output['name'] = $row['name'];
				$output['point'] = $row['point'];
				$output['age'] = $row['age'];
				$output['address'] = $row['address'];
			}
			echo json_encode($output);
		}
	}

	function update()
	{
		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('point', 'Point', 'required');
		if($this->form_validation->run())
		{	
			$data = array(
				'name'		=>	$this->input->post('name'),
				'point'			=>	$this->input->post('point'),
				'age'		=>	$this->input->post('age'),
				'address'			=>	$this->input->post('address')
			);

			$this->api_model->update_api($this->input->post('id'), $data);

			$array = array(
				'success'		=>	true
			);
		}
		else
		{
			$array = array(
				'error'				=>	ture,
				'name_error'	=>	form_error('name'),
				'point_error'	=>	form_error('point')
			);
		}
		echo json_encode($array);
	}




	function delete()
	{
		if($this->input->post('id'))
		{
			if($this->api_model->delete_single_user($this->input->post('id')))
			{
				$array = array(

					'success'	=>	true
				);
			}
			else
			{
				$array = array(
					'error'		=>	true
				);
			}
			echo json_encode($array);
		}
	}

}


?>